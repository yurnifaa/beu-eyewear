import Link from 'next/link';
import { Star } from 'lucide-react';
import ProductImage from '@/component/ProductImage';
import WishlistButton from '@/component/WishlistButton';

export interface ProductCardProps {
  slug?: string;
  name: string;
  price: string;
  // Struck-through list price, shown while a discount applies.
  compareAtPrice?: string;
  description?: string;
  href: string;
  imageUrl?: string;
  rating?: number;
  reviewCount?: number;
  colorSwatches?: { label: string; color: string }[];
  // Omit when stock isn't known; 0 shows the sold-out badge.
  stockQuantity?: number;
  className?: string;
}

export default function ProductCard({
  slug,
  name,
  price,
  compareAtPrice,
  description,
  href,
  imageUrl,
  rating,
  reviewCount,
  colorSwatches,
  stockQuantity,
  className = '',
}: ProductCardProps) {
  const soldOut = stockQuantity !== undefined && stockQuantity <= 0;
  const isFeatured = rating !== undefined;

  return (
    <Link href={href} className={`group block w-40 shrink-0 snap-start md:w-full ${className}`}>
      <div className="relative">
        <ProductImage
          imageUrl={imageUrl}
          alt={name}
          sizes="(min-width: 768px) 25vw, 160px"
          objectFit={isFeatured ? 'contain' : 'cover'}
          className={`${isFeatured ? 'aspect-square w-full rounded-2xl bg-white' : 'aspect-3/4 w-full rounded-2xl'} transition-transform duration-200 group-hover:-translate-y-1 ${soldOut ? 'opacity-60' : ''}`}
        />
        {soldOut && (
          <span className="absolute bottom-2 left-2 rounded-full bg-foreground px-2.5 py-1 text-xs font-semibold text-background">
            Out of stock
          </span>
        )}
        {!soldOut && compareAtPrice && (
          <span className="absolute bottom-2 left-2 rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-on-accent">
            Sale
          </span>
        )}
        {slug && <WishlistButton slug={slug} name={name} variant="icon" className="absolute right-2 top-2" />}
      </div>
      {isFeatured ? (
        <div className="relative mt-2 min-h-16 pr-12">
          <div className="flex items-center gap-1 text-[10px] leading-none">
            <Star size={12} className="fill-amber-500 text-amber-500" aria-hidden="true" />
            <span className="font-medium text-foreground">{rating.toFixed(1)}</span>
            {reviewCount !== undefined && <span className="text-muted-foreground">({reviewCount})</span>}
          </div>
          <p className="mt-1 line-clamp-2 font-display text-xs font-bold uppercase leading-snug tracking-tight text-foreground">{name}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {compareAtPrice && <span className="mr-1 line-through opacity-70">{compareAtPrice}</span>}
            {price}
          </p>
          {colorSwatches && colorSwatches.length > 0 && (
            <span className="absolute bottom-0 right-0 flex items-center gap-1" aria-label="Available colors">
              {colorSwatches.map((color) => (
                <span
                  key={color.label}
                  title={color.label}
                  aria-label={color.label}
                  className="size-2.5 rounded-full border border-black/10"
                  style={{ backgroundColor: color.color }}
                />
              ))}
            </span>
          )}
        </div>
      ) : (
        <>
      <div className="mt-3 flex flex-col gap-1 md:flex-row md:items-start md:justify-between md:gap-3">
        <p className="line-clamp-2 font-display text-xs font-bold uppercase leading-snug tracking-tight md:text-sm">{name}</p>
        <p className="text-xs font-medium md:shrink-0 md:text-sm">
          {compareAtPrice && <span className="mr-1.5 text-xs text-muted-foreground line-through">{compareAtPrice}</span>}
          {price}
        </p>
      </div>
      {description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{description}</p>}
        </>
      )}
    </Link>
  );
}
